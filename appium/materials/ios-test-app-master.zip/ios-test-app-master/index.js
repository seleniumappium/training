import { relative, absolute, appList, install, installRealDevice } from './install-npm';


export default appList;
export { relative, absolute, appList, install, installRealDevice };
