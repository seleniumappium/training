package com.sudheertech.demo;

import org.testng.annotations.Test;

public class TestDemo 
{
	@Test
	public void test1()
	{
		System.out.println("In Test1");
	}
	
	@Test
	public void test2()
	{
		System.out.println("In Test2");
	}
	
	@Test
	public void test3()
	{
		System.out.println("In Test3");
	}
}
