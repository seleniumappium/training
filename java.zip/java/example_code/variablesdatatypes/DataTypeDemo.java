package com.java.ex.variablesdatatypes;

public class DataTypeDemo
{
	byte byteVar = 10;
	short shortVar = 11;
	int inVar = 12;
	long longVar=13;
	float floatVar=14.12f;
	double doubleVar = 15.2345;
	char charVar = 'a';
	boolean booVar = false;
	
	
	public static void main(String[] args) {
		DataTypeDemo demo = new DataTypeDemo();
		System.out.println(demo.byteVar);
		System.out.println(demo.shortVar);
		System.out.println(demo.inVar);
		System.out.println(demo.longVar);
		System.out.println(demo.floatVar);
		System.out.println(demo.doubleVar);
		System.out.println(demo.charVar);
		System.out.println(demo.booVar);
	}
	
	
	
	
}
