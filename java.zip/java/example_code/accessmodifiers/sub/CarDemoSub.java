package com.java.ex.accessmodifiers.sub;

import com.java.ex.accessmodifiers.Car;

public class CarDemoSub {
	public static void main(String[] args) {
		Car c = new Car();
		
		
	}
}
