package com.java.ex.accessmodifiers;

public class CarDemo {
	public static void main(String[] args) {
		Car c = new Car();
		System.out.println(c.color);
		c.display();
	}
}
