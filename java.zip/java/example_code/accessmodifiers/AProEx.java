package com.java.ex.accessmodifiers;

public class AProEx {
	
	protected int modelNo= 1234;
	
	protected void msg()
	{
		System.out.println("In Msg");
	}
}
