package com.java.ex.accessmodifiers;

public class Car {

	int modelNo =1234;
	String color ="red";
	
	
	void display()
	{
		System.out.println("In display");
	}
	
	
}
