package com.java.ex.accessmodifiers;

public class PrivateExDemo {

	
	public static void main(String[] args) {
		PrivateEx ex = new PrivateEx();
	
	}
}
