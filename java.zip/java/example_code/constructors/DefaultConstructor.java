package com.java.ex.constructors;

public class DefaultConstructor {

	public DefaultConstructor() {

	}

	public static void main(String[] args) {
		DefaultConstructor defaultConstructor = new DefaultConstructor();
	}

	/*
	 * If you dont create a default constructor , java compiler will create it
	 * for you
	 */
}
