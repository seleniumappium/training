package com.java.ex.constructors;

public class Dog {

	int size;
	String color;
	String breedName;
	
	public static void main(String[] args) {
		Dog d = new Dog();
		System.out.println(d.size);
		System.out.println(d.color);
		System.out.println(d.breedName);
	}
	
	
}
