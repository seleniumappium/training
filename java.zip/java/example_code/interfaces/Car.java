package com.java.ex.interfaces;

public interface Car {

	String color="Red";
	public static final int modelNo=12345;;
	
	public abstract void speed();
	public abstract void applyBreak();
	void accelarate();

}
