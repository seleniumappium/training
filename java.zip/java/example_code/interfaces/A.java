package com.java.ex.interfaces;

public interface A {
	public void display();
	
	public void print();
}
