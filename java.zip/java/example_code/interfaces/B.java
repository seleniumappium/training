package com.java.ex.interfaces;

public interface B {
  public void display();
  
  public void view();
}
