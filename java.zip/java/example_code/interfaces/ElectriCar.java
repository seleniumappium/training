package com.java.ex.interfaces;

public interface ElectriCar {
	public void batter();
}
