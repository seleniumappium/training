/**
 * 
 */
/**
 * @author deepak
 *
 */
package com.java.ex.interfaces;