package com.java.ex;

public class ClassStructure 
{
	String color="red";
	int modelNo = 12345;

	public void displaDetails()
	{
		
	}
	

}
