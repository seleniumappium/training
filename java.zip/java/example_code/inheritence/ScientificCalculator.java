package com.java.ex.inheritence;

class Calculator
{
	
}

public class ScientificCalculator 
{

}