package com.java.ex.finalkeyword;

final public class FinalEx {
	final int modelno = 1234;
	
	
	public void display()
	{
		//modelno = 5678;
	}
	
	final public void print()
	{
		System.out.println("im in print");
	}
}
