package com.java.ex.finalkeyword;

//public class FinalExOverRiding extends FinalEx{
//
//	
//	public void display()
//	{
//		System.out.println("In display FinalExOverRiding");
//	}
//	
//	
////	public void print()
////	{
////		
////	}
//}
