package com.wordpress.constants;

public interface Constants 
{
	public String CHROME="chrome";
	
	public String FIREFOX="firefox";
	
	public String property_webdriver_chrome_driver = "webdriver.chrome.driver";
	
	public String property_webdriver_gecko_driver = "webdriver.gecko.driver";
	
	public String valid_user_name="sudheerkumar.gv@gmail.com";
	
	public String valid_password="kumar@123";
}
